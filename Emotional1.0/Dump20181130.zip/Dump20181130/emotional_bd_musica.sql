-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: emotional_bd
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `musica`
--

DROP TABLE IF EXISTS `musica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `musica` (
  `Id_musica` int(11) NOT NULL AUTO_INCREMENT,
  `arquivo_musica` varchar(150) NOT NULL,
  `Titulo_musica` varchar(45) NOT NULL,
  `tempo_musica` int(11) DEFAULT NULL,
  `Id_emocao` int(11) NOT NULL,
  `Id_estilo_musical` int(11) NOT NULL,
  `Id_Artista` int(11) NOT NULL,
  PRIMARY KEY (`Id_musica`),
  KEY `Id_emocao` (`Id_emocao`),
  KEY `Id_estilo_musical` (`Id_estilo_musical`),
  KEY `Id_Artista` (`Id_Artista`),
  CONSTRAINT `musica_ibfk_1` FOREIGN KEY (`Id_emocao`) REFERENCES `emocao` (`id_emocao`),
  CONSTRAINT `musica_ibfk_2` FOREIGN KEY (`Id_estilo_musical`) REFERENCES `estilo_musical` (`id_estilo_musical`),
  CONSTRAINT `musica_ibfk_3` FOREIGN KEY (`Id_Artista`) REFERENCES `artista` (`id_artista`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `musica`
--

LOCK TABLES `musica` WRITE;
/*!40000 ALTER TABLE `musica` DISABLE KEYS */;
INSERT INTO `musica` VALUES (3,'C:\\Users\\USER\\Music\\Playlists\\fala sonia.mp3','Natal',NULL,2,3,17),(11,'C:\\Users\\USER\\Music\\Playlists\\fala sonia - Copia (2).mp3','Musica',NULL,2,3,18),(12,'C:\\Users\\USER\\Music\\Playlists\\fala sonia - Copia.mp3','Beija Minha Boka',NULL,2,3,18),(13,'C:\\Users\\USER\\Music\\Playlists\\C:\\Users\\USER\\Music\\Playlists\\Elton John - Agora vai Sentar (cover MCs Jhowzinho & Kadinho).mp3','Agora vai sentar',NULL,2,2,18),(14,'C:\\Users\\USER\\Music\\Playlists\\Elton John - Agora vai Sentar.mp3','Sentar',NULL,2,2,18),(15,'C:\\Users\\USER\\Music\\Playlists\\Elton John - Agora vai Sentar.mp3','habla sonia',NULL,2,3,18),(16,'C:\\Users\\USER\\Music\\Playlists\\Natal.mp3','Talk Sonia',NULL,3,2,18),(17,'C:\\Users\\USER\\Music\\Playlists\\fala sonia - Copia (3).mp3','Diga Sonia',NULL,2,3,18),(18,'C:\\Users\\USER\\Music\\Playlists\\fala sonia.mp3','Vamos Sonia',NULL,2,3,18),(19,'C:\\Users\\USER\\Music\\Playlists\\Elton John - Agora vai Sentar.mp3','Poxa Sonia',NULL,2,3,18),(20,'C:\\Users\\USER\\Music\\Playlists\\fala sonia - Copia (2).mp3','Fala logo Sonia',NULL,2,6,18),(21,'C:\\Users\\USER\\Music\\Playlists\\Natal.mp3','Meu deus Sonia',NULL,2,3,18),(22,'C:\\Users\\USER\\Music\\Playlists\\Elton John - Agora vai Sentar.mp3','Finalmente Sonia',NULL,2,3,18);
/*!40000 ALTER TABLE `musica` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-30 18:59:48
