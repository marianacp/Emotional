-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: emotional_bd
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `usuario` (
  `Id_usu` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `Data_nascimento` date NOT NULL,
  `CPF` varchar(45) NOT NULL,
  `Ativo` bit(1) DEFAULT b'0',
  `Premium` bit(1) DEFAULT b'0',
  `Senha` varchar(45) NOT NULL,
  `Login` varchar(45) NOT NULL,
  `Foto` varchar(80) DEFAULT NULL,
  `Id_emocao` int(11) DEFAULT NULL,
  `tipoUsuario` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`Id_usu`),
  KEY `Id_emocao` (`Id_emocao`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`Id_emocao`) REFERENCES `emocao` (`id_emocao`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Eymael','eymael@uniriotec.br','2018-10-25','123456677',_binary '',_binary '\0','1234','mama','IMG-20161106-WA0028.jpg',NULL,'A'),(2,'Juliana','juju@hotmail.com','2018-10-25','12334456768',_binary '',_binary '\0','12345','Juju','IMG-20161202-WA0045.jpg',NULL,NULL),(3,'Vco','vco@hotmail.com','2018-10-25','12345666777',_binary '',_binary '\0','789456','Vico','IMG-20161123-WA0020.jpg',NULL,NULL),(4,'Caz','coz@hotmail.com','2018-10-25','13456677',_binary '',_binary '\0','67478','coz','IMG-20161104-WA0032.jpg',NULL,NULL),(5,'alguma coisa','algo@rotmail.com','2018-10-25','12434567',_binary '',_binary '\0','45565','algo','IMG-20161118-WA0000.jpg',NULL,NULL),(6,'Vinicius','viniciuscondina@hotmail.com','2018-10-26','1645897554',_binary '',_binary '\0','45489','Condina','IMG-20161105-WA0033.jpg',NULL,NULL),(8,'Jose augusto','augusto@gmail.com','2018-10-26','16438312758',_binary '\0',_binary '\0','12345','Augustinho','IMG-20161128-WA0017.jpg',NULL,NULL),(9,'Carlos','viniciuscondina@gmail','2018-11-10','4155162623',_binary '\0',_binary '\0','12324','Tevez','Capturar.PNG',NULL,NULL),(10,'Vinicius','cond@hotmail.com','2018-11-16','164378236641',_binary '',_binary '\0','1234','Condina','Capturar.PNG',2,'M'),(11,'Romero','romero@gmail.com','2018-11-16','1558574565',_binary '',_binary '\0','1234','Brito','cha mini cartao frente.png',NULL,NULL),(12,'joge','joge@gmail','2018-11-18','21355645',_binary '',_binary '\0','1234','jroginho','agua-gelada.jpg',NULL,NULL),(17,'Jorge','jorgew@gmail.com','2018-11-18','12343455',_binary '',_binary '\0','2345','Jorginho','agua-gelada.jpg',2,'O'),(18,'jefdwefwr','ver@gmail.com','2018-11-18','5445554',_binary '',_binary '\0','1234','rfrere','C:\\Users\\USER\\Pictures\\cha mini cartao costas.png',NULL,'M'),(20,'Novo','viniciuscondina@gmail.com','2018-11-22','12345666',_binary '',_binary '\0','1234','novin','cha mini cartao costas.png',NULL,'O'),(21,'Vini','aa@gmail.com','2018-11-24','1643838127',_binary '',_binary '\0','1234','Cond','C:\\Users\\USER\\Pictures\\14456415750.jpg',2,'M');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-30 18:59:43
